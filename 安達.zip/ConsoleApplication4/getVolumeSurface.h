#include <iostream>
double getVolumeSurface(double width, double height, double depth, double *volume, double *surfaceArea);
